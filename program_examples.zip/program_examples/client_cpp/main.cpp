#include <iostream>
#include <thread>
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#include "shmipc.h"
#include "client.h"

//using namespace std;

//bool g_ExitDone;

int main(int argc, char *argv[])
{
//    shmipc control;
Client control;
    int data;
    int cmd;
    int position;
    int dx;
    data=10;
    cmd='L';
//    system("./socket_server &>/dev/null &");
    control.start();
    control.left(data);

    while(1)
    {

//    control.write_cs(cmd,data);
control.readstatus();
//    control.read_dp(&dx,&position);
printf("dx: %d pos: %d\n",control.getDx(),control.getPos());
    if(control.ifPositionLeft())
     {
      control.right(data);
     }
    if(control.ifPositionRight())
     {
      control.left(data);      
     }
    usleep(100*1000);
//          fprintf(stderr,"wait done\n");

     }
}
